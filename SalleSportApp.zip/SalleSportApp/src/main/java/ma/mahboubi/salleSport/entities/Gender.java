package ma.mahboubi.salleSport.entities;

public enum Gender {
    Male,
    Female;
}
