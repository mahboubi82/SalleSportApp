package ma.mahboubi.salleSport.entities;

public class Subscription {
}
